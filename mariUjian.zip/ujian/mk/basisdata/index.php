<?php

session_start();
if (isset($_SESSION['nim']) && isset($_SESSION['nama']) && isset($_SESSION['prodi'])) {
    // user sudah login, lakukan aksi yang diinginkan
    $nim = $_SESSION['nim'];
    $nama = $_SESSION['nama'];
    $prodi = $_SESSION['prodi'];
} else {
    // user belum login, redirect ke halaman login
    header('Location: ../login/');
    exit;
}
// kalau user tidak memiliki Id soal, maka akan dikembalikan ke halaman index
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $_SESSION['id'] = $id;
} else {
    header('Location:../../../ujian/index.php');
};
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ruang Ujian | UNBN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css.css">
    <link rel="stylesheet" href="../css.css">
</head>

<body>
    <!-- timer -->
    <div id="timer" class="fixed-top"></div>
    <div class="container pt-5" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="1000">
        <h3>
            Selamat Melaksanakan Ujian:
            <b style="color:brown">
                <?php echo $nama ?>
            </b>
            <a href="../../logout.php" class="btn btn-danger" style="float:right;">Keluar</a>
        </h3>

    </div>
    <!--  -->
    <section class="jumbotron">
        <div class="container shadow mt-5 pt-2" style="background:white;">
            <!-- bungkus ke dalam form -->
            <form method="POST" action="../../cek_jawaban.php?id=$id">
                <div class="card">
                    <div class="card-header">
                        <h3 class="p-3">
                            Lengkapi data berikut:
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm mt-3">
                                <label for="nama">Nama Lengkap</label>
                                <i style="color:red; font-size:12px">*(Data ini tidak perlu dirubah!)</i>
                                <input name="nama_mhs" type="text" class="form-control"
                                    value="<?= $nama;?>">
                            </div>
                            <div class="col-sm-6 mt-3">
                                <label for="nama">NIM</label>
                                <i style="color:red; font-size:12px">*(Data ini tidak perlu dirubah!)</i>
                                <input name="nim" type="text" class="form-control"
                                    value="<?php echo $nim;?>">
                            </div>
                            <div class="col-sm-6 mt-3">
                                <label for="nama">Kode Mata Kuliah</label>
                                <i style="color:red; font-size:12px">*(Data ini tidak perlu dirubah!)</i>
                                <input name="id_mk" type="text" class="form-control"
                                    value="<?php echo $id;?>">
                            </div>
                            <div class="col-sm-6 mt-3">
                                <label for="nama"> </label>
                                <div class="form-floating">
                                    <select name="id_prodi" class="form-select" id="floatingSelect"
                                        aria-label="Floating label select example">
                                        <option selected>Pilih</option>
                                        <option value="1">Teknik Informatika</option>
                                    </select>
                                    <label for="floatingSelect">Program Studi: </label>
                                </div>


                            </div>
                            <div class=" col-sm-6 mt-3">
                                <label for="nama">Ujian</label>
                                <select name="ket_ujian" class="form-control" required>
                                    <option value="">- Pilih ujian -</option>
                                    <option value="1">UTS</option>
                                    <option value="2">UAS</option>
                                </select>
                            </div>
                        </div>
                    </div>





                </div>
                <br>
                <hr>
                <br>
                <div class="row">
                    <h3 class="pb-3">
                        Silahkan mengerjakan Soal berikut:
                    </h3>
                    <?php

                     include'../../config.php';

$no = 1;
$kueri = mysqli_query($conn, "SELECT * from tb_soal where id_mk='$id'");
while ($data= mysqli_fetch_array($kueri)) {
    ?>
                    <div class="col">


                        <div class="col mt-3 pt-2">
                            <label
                                class="mt-1"><?= $no++ .'. '. $data['s1'];?></label>
                            <select class="form-control" name="j1" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a. Ms. Acces</option>
                                <option value="b">b. Ms. Excel</option>
                                <option value="c">c. Ms. Word</option>
                            </select>
                        </div>
                        <div class="col mt-3 pt-2">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s2'];?></label>
                            <select class="form-control" name="j2" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a. Ctrl + A</option>
                                <option value="b">b. Ctrl + C</option>
                                <option value="c">c. Ctrl + I</option>
                            </select>
                        </div>
                        <div class="col mt-3 pt-2">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s3'];?></label>
                            <select class="form-control" name="j3" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a. Ctrl + V</option>
                                <option value="b">b. Ctrl + Z</option>
                                <option value="c">c. Ctrl + B</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s4'];?></label>
                            <select class="form-control" name="j4" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a. Home</option>
                                <option value="b">b. Insert</option>
                                <option value="c">c. View</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s5'];?></label>
                            <select class="form-control" name="j5" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a. Insert</option>
                                <option value="b">b. View</option>
                                <option value="c">c. Reference</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s6'];?></label>
                            <select class="form-control" name="j6" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c. fgbs</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s7'];?></label>
                            <select class="form-control" name="j7" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s8'];?></label>
                            <select class="form-control" name="j8" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s9'];?></label>
                            <select class="form-control" name="j9" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s10'];?></label>
                            <select class="form-control" name="j10" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s11'];?></label>
                            <select class="form-control" name="j11" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s12'];?></label>
                            <select class="form-control" name="j12" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s13'];?></label>
                            <select class="form-control" name="j13" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s14'];?></label>
                            <select class="form-control" name="j14" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s15'];?></label>
                            <select class="form-control" name="j15" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s16'];?></label>
                            <select class="form-control" name="j16" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s17'];?></label>
                            <select class="form-control" name="j17" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s18'];?></label>
                            <select class="form-control" name="j18" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s19'];?></label>
                            <select class="form-control" name="j19" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s20'];?></label>
                            <select class="form-control" name="j20" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s21'];?></label>
                            <select class="form-control" name="j21" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s22'];?></label>
                            <select class="form-control" name="j22" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s23'];?></label>
                            <select class="form-control" name="j23" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s24'];?></label>
                            <select class="form-control" name="j24" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s25'];?></label>
                            <select class="form-control" name="j25" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s26'];?></label>
                            <select class="form-control" name="j26" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s27'];?></label>
                            <select class="form-control" name="j27" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s28'];?></label>
                            <select class="form-control" name="j28" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s29'];?></label>
                            <select class="form-control" name="j29" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                        <div class="col mt-3">
                            <label
                                class="m-1"><?= $no++ .'. '. $data['s30'];?></label>
                            <select class="form-control" name="j30" id="" cols="10" rows="3">
                                <option value="">Pilih Jawaban</option>
                                <option value="a">a.</option>
                                <option value="b">b.</option>
                                <option value="c">c.</option>
                            </select>
                        </div>
                    </div>
                    <?php }?>
                </div>
                <button id="submit_kirim" type="submit" class="btn btn-success mt-3 mb-5" name="submit">Kirim
                    jawaban</button>

            </form>
        </div>
    </section>
    <!-- mp3 -->
    <div class="musikMp3">
        <audio id="audio" src="../../mp3/audio.mp3"></audio>
        <button class="btn btn-warning" onclick="mainkan()">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-music-note"
                viewBox="0 0 16 16">
                <path d="M9 13c0 1.105-1.12 2-2.5 2S4 14.105 4 13s1.12-2 2.5-2 2.5.895 2.5 2z" />
                <path fill-rule="evenodd" d="M9 3v10H8V3h1z" />
                <path d="M8 2.82a1 1 0 0 1 .804-.98l3-.6A1 1 0 0 1 13 2.22V4L8 5V2.82z" />
            </svg></button>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
    <!-- putar musik -->
    <script src="../mp3.js"></script>
    <!-- script untuk kirim jawaban secara otomatis -->
    <script src="../kirimOtomatis.js"> </script>
    <!-- timer -->
    <script src="../timer.js"> </script>
</body>

</html>
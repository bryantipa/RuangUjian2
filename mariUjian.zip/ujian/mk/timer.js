// atur waktu awal
var countDownDate = new Date().getTime() + 2700 * 1000; // 5 detik dari sekarang

// update timer setiap 1 detik
var x = setInterval(function () {
  // ambil waktu sekarang
  var now = new Date().getTime();

  // hitung selisih waktu antara sekarang dan waktu awal
  var distance = countDownDate - now;

  // hitung waktu dalam jam, menit, dan detik
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // tampilkan waktu dalam elemen dengan id="timer"
  document.getElementById("timer").innerHTML =
    "Waktu Ujian : " + hours + " " + minutes + " " + seconds + " detik";

  // jika waktu telah habis, hentikan timer
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("timer").innerHTML = "Waktu habis";
  }
}, 1000); // interval timer setiap 1 detik

// tangkap id musik
var audio = document.getElementById("audio");

function mainkan() {
  if (audio.paused) {
    audio.play();
  } else {
    audio.pause();
  }
}

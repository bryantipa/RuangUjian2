const kirimBtn = document.getElementById("submit_kirim");

// update timer setiap 1 detik
var x = setInterval(function () {
  function kirimJawaban() {
    kirimBtn.click();
    if (kirimBtn == true) {
      console.log("data berhasil");
    } else {
      console.log("data gagal terkirim");
    }
    // kirim data ke server di sini
  }
  setTimeout(kirimJawaban, 2700 * 1000);
}, 1000); // interval timer setiap 1 detik

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ruang Ujian | UNBN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../css.css">
    <link rel="stylesheet" href="css.css">
  </head>
  <body>
    
    <!--  -->
    <section class="jumbotron">
        <div class="container shadow p-5" style="background:white;">
            <form action="cek_jawaban.php" method="POST">
                <div class="row">
                    <h3 class="pb-3">
                        Lengkapi data berikut:
                    </h3>
                    <div class="col-sm-6">
                        <label for="nama">Nama Lengkap</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="col-sm-6">
                        <label for="nama">NIM</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="col-sm-6">
                        <label for="nama">Program Studi</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="col-sm-6">
                        <label for="nama">Ujian</label>
                        <select class="form-control" required>
                            <option value="">- Pilih ujian -</option>
                            <option value="1">UTS</option>
                            <option value="2">UAS</option>
                        </select>
                    </div>
                </div>
                <br>
                <hr>
                <br>
                <div class="row">
                    <h3 class="pb-3">
                        Silahkan mengerjakan Soal berikut:
                    </h3>
                    <div class="col">
                        <label class="m-1">1. Siapakah nama dari presiden RI 2023?</label>
                        <textarea class="form-control" name="" id="" cols="10" rows="3"></textarea>
                    </div>
                    <!--  -->
                    <h3 class="pb-3">
                        Silahkan mengerjakan Soal berikut:
                    </h3>
                    <div class="col">
                        <label class="m-1">2. Siapakah nama dari presiden RI 2023?</label><br>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                </div>
                <button class="btn btn-success mt-3">
                    Kirim jawaban
                </button>
            </form>
        </div>
    </section>




 
    <!-- musik -->
    <div class="musik fixed-bottom"> 
        <audio id="audio" src="mp3/audio.mp3" type="audio/mp3" ></audio>
        <a class="btn btn-warning shadow" onclick="mainkan()">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-music-note-list" viewBox="0 0 16 16">
                <path d="M12 13c0 1.105-1.12 2-2.5 2S7 14.105 7 13s1.12-2 2.5-2 2.5.895 2.5 2z"/>
                <path fill-rule="evenodd" d="M12 3v10h-1V3h1z"/>
                <path d="M11 2.82a1 1 0 0 1 .804-.98l3-.6A1 1 0 0 1 16 2.22V4l-5 1V2.82z"/>
                <path fill-rule="evenodd" d="M0 11.5a.5.5 0 0 1 .5-.5H4a.5.5 0 0 1 0 1H.5a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 .5 7H8a.5.5 0 0 1 0 1H.5a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 .5 3H8a.5.5 0 0 1 0 1H.5a.5.5 0 0 1-.5-.5z"/>
            </svg>
        </a>
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script>
        // tangkap id musik
        var audio = document.getElementById('audio');
        function mainkan() {
            if(audio.paused){
                audio.play()
            }else{
                audio.pause();
            }
        }
    </script>
  </body>
</html>
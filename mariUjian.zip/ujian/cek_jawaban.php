<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<?php
session_start();
if (isset($_SESSION['nim']) && isset($_SESSION['nama']) && isset($_SESSION['prodi'])) {
    // user sudah login, lakukan aksi yang diinginkan
    $nim = $_SESSION['nim'];
    $nama = $_SESSION['nama'];
    $prodi = $_SESSION['prodi'];
} else {
    // user belum login, redirect ke halaman login
    header('Location: ../login/');
    exit;
}
// kalau user tidak memiliki Id soal, maka akan dikembalikan ke halaman index
// if (isset($_GET['id'])) {
//     $id = $_GET['id'];
// } else {
//     header('Location:../../ujian/index.php');
// };
// koneksi
include 'config.php';

if (isset($_POST['submit'])) {
    $nama = $_POST['nama_mhs'];
    $nim = $_POST['nim'];
    $id_mk = $_POST['id_mk'];
    $id_prodi = $_POST['id_prodi'];
    $ket_ujian = $_POST['ket_ujian'];

    // bagian jawabannya
    $j1 = $_POST['j1'];
    $j2 = $_POST['j2'];
    $j3 = $_POST['j3'];
    $j4 = $_POST['j4'];
    $j5 = $_POST['j5'];
    $j6 = $_POST['j6'];
    $j7 = $_POST['j7'];
    $j8 = $_POST['j8'];
    $j9 = $_POST['j9'];
    $j10 = $_POST['j10'];
    $j11 = $_POST['j11'];
    $j12 = $_POST['j12'];
    $j13 = $_POST['j13'];
    $j14 = $_POST['j14'];
    $j15 = $_POST['j15'];
    $j16 = $_POST['j16'];
    $j17 = $_POST['j17'];
    $j18 = $_POST['j18'];
    $j19 = $_POST['j19'];
    $j20 = $_POST['j20'];
    $j21 = $_POST['j21'];
    $j22 = $_POST['j22'];
    $j23 = $_POST['j23'];
    $j24 = $_POST['j24'];
    $j25 = $_POST['j25'];
    $j26 = $_POST['j26'];
    $j27 = $_POST['j27'];
    $j28 = $_POST['j28'];
    $j29 = $_POST['j29'];
    $j30 = $_POST['j30'];


    // kita lakukan pengecekkan dahulu, apakah mhs tersebut sdh pernah mengisi jawaban
    $query = "SELECT * FROM tb_jawaban WHERE nama_mhs = '$nama' AND nim = '$nim' AND id_mk = '$id_mk' AND ket_ujian = '$ket_ujian'";
    $result = mysqli_query($conn, $query);
    // jika jawaban sudah pernah dikirimkan
    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Jawaban sudah pernah dikirimkan.');</script>";
        echo  "<div class='container'><h3>Jawaban anda sudah ada :</h3></div>";
        echo "<div class='container'><a href='hasil.php'><button class='btn btn-primary'>Lihat Hasil Ujian</button> </a></div>";
    } else {
        // jika belum pernah mengirim jawaban
        // insert data ke dalam tabel tb_jawaban
        $query = "INSERT INTO tb_jawaban (nama_mhs, nim, id_mk, id_prodi, ket_ujian, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12, j13, j14, j15, j16, j17, j18, j19, j20, j21, j22, j23, j24, j25, j26, j27, j28, j29, j30) 
VALUES ('$nama', '$nim', '$id_mk', '$id_prodi', '$ket_ujian', '$j1', '$j2', '$j3', '$j4', '$j5', '$j6', '$j7', '$j8', '$j9', '$j10', '$j11', '$j12', '$j13', '$j14', '$j15', '$j16', '$j17', '$j18', '$j19', '$j20', '$j21', '$j22', '$j23', '$j24', '$j25', '$j26', '$j27', '$j28', '$j29', '$j30')";

        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Data berhasil ditambahkan.');</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
        header('location:hasil.php');
    };
} else {
    echo "<script>console.log('Silahkan hubungi Call Center!');</script>";
}
?>




















<!-- <div class='container p-5 m-5'>
    <div class='card'>
        <div class='card-header bg-danger'>
            <h3 style='color:white;'>
                Peringatan!
            </h3>
        </div>
        <div class='card-body'>
            <p>Jawaban anda sudah pernah dikirimkan, sehingga anda tidak dapat mengirim jawaban lagi <br> silahkan
                mengunggu jadwal Remidi dari <b>dosen pengampuh Mata Kuliah,</b> Terimakasih.</p>
            <a class='btn btn-danger' href='index.php'>Kembali</a>
        </div>
    </div>
</div> -->
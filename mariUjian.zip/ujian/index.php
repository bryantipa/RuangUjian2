<?php

session_start();
if (isset($_SESSION['nim']) && isset($_SESSION['nama']) && isset($_SESSION['prodi'])) {
    // user sudah login, lakukan aksi yang diinginkan
    $nim = $_SESSION['nim'];
    $nama = $_SESSION['nama'];
    $prodi = $_SESSION['prodi'];
} else {
    // user belum login, redirect ke halaman login
    header('Location: ../login/');
    exit;
}
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ruang Ujian | UNBN</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <link rel="stylesheet" href="../css.css">

  <!-- aos -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>

<body>
  <section class="jumbotron">
    <div class="container" data-aos="fade-up" data-aos-anchor-placement="center-bottom" data-aos-duration="1000">
      <h3>
        Selamat datang
        <b style="color:brown">
          <?php echo $nama ?>
        </b>
        <a href="logout.php" class="btn btn-danger m-1" style="float:right;">Keluar</a>
        <a href="hasil.php" class="btn btn-success m-1" style="float:right;">Hasil</a>


      </h3>

    </div>
  </section>
  <section class="jumbotron">
    <div class="container rounded-5 shadow p-4" style="background:white;">
      <div class="row">
        <?php
                    if ($prodi == 1) {
                        include'kelas/ti.php';
                    } elseif ($prodi == 2 or 3 or 4 or 5) {
                        include'kelas/umum.php';
                    }

?>
      </div>
    </div>
    </div>
  </section>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
  </script>
  <!-- aos -->
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>
</body>

</html>
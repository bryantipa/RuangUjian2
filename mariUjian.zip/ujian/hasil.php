<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<?php
session_start();
if (isset($_SESSION['nim']) && isset($_SESSION['nama']) && isset($_SESSION['prodi'])) {
    // user sudah login, lakukan aksi yang diinginkan
    $nim = $_SESSION['nim'];
    $nama = $_SESSION['nama'];
    $prodi = $_SESSION['prodi'];
} else {
    // user belum login, redirect ke halaman login
    header('Location: ../login/');
    exit;
}
?>

<div class="m-5 card shadow">
    <table class="table text-center">

        <div class="card-header bg-success">
            <h3 style="color:white">Hasil Ujian : <?php echo $nama;?>
            </h3>
            <thead>
                <tr>
                    <th class="text-center">ID Jawaban</th>
                    <th class="text-center">Nama</th>
                    <th class="text-center">NIM</th>
                    <th class="text-center">PRODI</th>
                    <th class="text-center">MATA KULIAH</th>
                    <th class="text-center">JENIS UJIAN</th>
                    <th class="text-center">HASIL</th>
                    <th class="text-center">HURUF</th>
                </tr>
            </thead>

        </div>
        <div class="card-body">
            <tbody>
                <?php
    include'../login/config.php';

$query = "SELECT * FROM tb_jawaban WHERE nama_mhs = '$nama' AND nim = '$nim'";
$result = mysqli_query($conn, $query);
$no=1;

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while ($data = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $no++;?></td>
                    <td><?php echo $data['nama_mhs'];?>
                    </td>
                    <td><?php echo $data['nim']?>
                    </td>
                    <td><?php
            if ($data['id_prodi'] == 1) {
                echo "Teknik Informatika";
            } elseif ($data['id_prodi'] == 2) {
                echo "Ilmu Pemerintahan";
            } elseif ($data['id_prodi'] == 3) {
                echo "Manajemen";
            } elseif ($data['id_prodi'] == 4) {
                echo "Agroteknologi";
            } elseif ($data['id_prodi'] == 5) {
                echo "Ekonomi Pembangunan";
            } else {
                echo "Tidak ketemu";
            }
        ?>

                    </td>
                    <td><?php
            $id_mk = $data['id_mk'];
        if ($data['id_mk'] == "111") {
            echo "Perancangan Basis Data"  ;
        } elseif ($data['id_mk'] == 112) {
            echo "Sistem Informasi";
        } elseif ($data['id_mk'] == 113) {
            echo "Pengantar Komputer 2";
        } else {
            echo "Tidak ketemu";
        };
        ?></td>
                    <td><?php
if ($data['ket_ujian'] == 1) {
    echo "UTS";
} elseif ($data['ket_ujian'] == 2) {
    echo "UAS";
} else {
    echo "Anda belum mengikuti Ujian.";
}
        ;?>
                    </td>
                    <td><?php
            if ($data['j1'] == "c") {
                $j1 = 4;
            } else {
                $j1 = 0;
            }

            if ($data['j2'] == "c") {
                $j2 = 4;
            } else {
                $j2 = 0;
            }

            if ($data['j3'] == "c") {
                $j3 = 4;
            } else {
                $j3 = 0;
            }

            if ($data['j4'] == "c") {
                $j4 = 4;
            } else {
                $j4 = 0;
            }

            if ($data['j5'] == "c") {
                $j5 = 4;
            } else {
                $j5 = 0;
            }

            if ($data['j6'] == "c") {
                $j6 = 4;
            } else {
                $j6 = 0;
            }

            if ($data['j7'] == "c") {
                $j7 = 4;
            } else {
                $j7 = 0;
            }

            if ($data['j8'] == "c") {
                $j8 = 4;
            } else {
                $j8 = 0;
            }

            if ($data['j9'] == "c") {
                $j9 = 4;
            } else {
                $j9 = 0;
            }

            if ($data['j10'] == "c") {
                $j10 = 4;
            } else {
                $j10 = 0;
            }

            if ($data['j11'] == "c") {
                $j11 = 4;
            } else {
                $j11 = 0;
            }

            if ($data['j12'] == "c") {
                $j12 = 4;
            } else {
                $j12 = 0;
            }

            if ($data['j13'] == "c") {
                $j13 = 4;
            } else {
                $j13 = 0;
            }

            if ($data['j14'] == "c") {
                $j14 = 4;
            } else {
                $j14 = 0;
            }

            if ($data['j15'] == "c") {
                $j15 = 4;
            } else {
                $j15 = 0;
            }

            if ($data['j16'] == "c") {
                $j16 = 4;
            } else {
                $j16 = 0;
            }

            if ($data['j17'] == "c") {
                $j17 = 4;
            } else {
                $j17 = 0;
            }

            if ($data['j18'] == "c") {
                $j18 = 4;
            } else {
                $j18 = 0;
            }

            if ($data['j19'] == "c") {
                $j19 = 4;
            } else {
                $j19 = 0;
            }

            if ($data['j20'] == "c") {
                $j20 = 4;
            } else {
                $j20 = 0;
            }

            if ($data['j21'] == "c") {
                $j21 = 4;
            } else {
                $j21 = 0;
            }

            if ($data['j22'] == "c") {
                $j22 = 4;
            } else {
                $j22 = 0;
            }

            if ($data['j23'] == "c") {
                $j23 = 4;
            } else {
                $j23 = 0;
            }

            if ($data['j24'] == "c") {
                $j24 =4;
            } else {
                $j24 = 0;
            }

            if ($data['j25'] == "c") {
                $j25 = 4;
            } else {
                $j25 = 0;
            }

            if ($data['j26'] == "c") {
                $j26 = 4;
            } else {
                $j26 = 0;
            }

            if ($data['j27'] == "c") {
                $j27 = 4;
            } else {
                $j27 = 0;
            }

            if ($data['j28'] == "c") {
                $j28 = 4;
            } else {
                $j28 = 0;
            }

            if ($data['j29'] == "c") {
                $j29 = 4;
            } else {
                $j29 = 0;
            }

            if ($data['j30'] == "c") {
                $j30 = 4;
            } else {
                $j30 = 0;
            }




        $total = $j1 + $j2 + $j3 + $j4 + $j5 + $j6 + $j7 + $j8 + $j9 + $j10 + $j11 + $j12 + $j13 + $j14 + $j15 + $j16 + $j17 + $j18 + $j19 + $j20 + $j21 + $j22 + $j23 + $j24 + $j25 + $j26 + $j27 + $j28 + $j29 + $j30;
        echo $total;

        ?>
                    </td>
                    <td>
                        <?php
                        if ($total <= 44) {
                            echo "E";
                        } elseif ($total <= 54) {
                            echo "D";
                        } elseif ($total <= 69) {
                            echo "C";
                        } elseif ($total <= 84) {
                            echo "B";
                        } else {
                            echo "A";
                        }; ?>
                    </td>
                </tr>

                <?php }
    } else {
        echo "0 results";
    }
?>
            </tbody>
        </div>
    </table>
</div>
<?php
// Query untuk mencari data berdasarkan nama dan nim
// $kueri_cek = mysqli_query($conn, "SELECT * FROM tb_jawaban WHERE nama_mhs = '$nama' AND nim = '$nim'");

// Cek apakah data ditemukan
// if (mysqli_num_rows($kueri_cek) > 0) {
    // Jika ditemukan, gunakan query UPDATE untuk mengubah nilai
    // $kuery = mysqli_query($conn, "INSERT INTO tb_jawaban (total_nilai) values('$total')");
// $kueri_update = mysqli_query($conn, "UPDATE tb_jawaban SET total_nilai='$total' WHERE nim='$nim'");
// if ($kueri_update) {
    //     echo "Data berhasil diubah";
// } else {
    //     echo "Data gagal diubah";
// }
// } else {
    // Jika tidak ditemukan, munculkan
    // echo "Data tidak tersedia";
// }

?>
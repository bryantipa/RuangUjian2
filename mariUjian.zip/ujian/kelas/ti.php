<?php

// session_start();
if (isset($_SESSION['nim']) && isset($_SESSION['nama']) && isset($_SESSION['prodi'])) {
    // user sudah login, lakukan aksi yang diinginkan
    $nim = $_SESSION['nim'];
    $nama = $_SESSION['nama'];
    $prodi = $_SESSION['prodi'];
} else {
    // user belum login, redirect ke halaman login
    header('Location: ../login/');
    exit;
}
// kalau user tidak memiliki Id soal, maka akan dikembalikan ke halaman index
// if (isset($_GET['id'])) {
//     $id = $_GET['id'];
// } else {
//     header('Location:index.php');
// };
//?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Ruang Ujian | UNBN</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous" />
  <link rel="stylesheet" href="../css.css" />
  <link rel="stylesheet" href="css.css" />

  <!-- aos -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>

<body>
  <div class="row">
    <div class="col-sm-6" data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="2000">
      <div class="card border border-primary-subtle shadow p-3">
        <div class="card-header" style="background:#2983e4;color:white;">
          <h3>Perancangan Basisdata</h3>
        </div>
        <div class="card-body">
          <h5 class="card-title">Deskripsi:</h5>
          <p class="card-text">
            Perancangan basis data adalah proses merancang struktur data dan
            aturan-aturan yang diperlukan untuk mengorganisir dan menyimpan
            data secara efisien dalam sebuah sistem basis data.

          </p>
          <a href="mk/basisdata/index.php?id=111" class="btn btn-primary">Mulai Ujian</a>
        </div>
      </div>
    </div>
    <div class="col-sm-6" data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="2000">
      <div class="card border border-primary-subtle shadow p-3">
        <div class="card-header" style="background:#2983e4;color:white;">
          <h3>Sistem Operasi</h3>
        </div>
        <div class="card-body">
          <h5 class="card-title">Deskripsi:</h5>
          <p class="card-text">
            Sistem operasi adalah perangkat lunak yang bertanggung jawab untuk
            mengatur, mengelola, dan mengkoordinasikan sumber daya dan
            aktivitas pada suatu komputer atau perangkat yang terhubung.
          </p>
          <a href="#" class="btn btn-primary">Mulai Ujian</a>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
  </script>
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>
</body>

</html>
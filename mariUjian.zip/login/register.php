<?php

include 'config.php';

// error_reporting(0);

// session_start();

// if (isset($_SESSION['username'])) {
//     header("Location: index.php");
// }

if (isset($_POST['submit'])) {
    $nim = $_POST['nim'];
    $nama_mhs = $_POST['nama'];
    $prodi = $_POST['prodi'];
    $email = $_POST['email'];

    // login user
    $password = md5($_POST['password']);
    $cpassword = md5($_POST['cpassword']);

    if ($password == $cpassword) {
        // cek apakah email tersebut sudah terdaftar sebelumnya ataukah belum?
        $sql = "SELECT * FROM tb_mhs WHERE  nim='$nim' ";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) === 0) {
            $sql = "INSERT INTO tb_mhs (nim, nama_mhs, kode_prodi, email,  login_pass)
                    VALUES ('$nim', '$nama_mhs','$prodi','$email',  '$password')";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<script>alert('Selamat, registrasi berhasil!')</script>";
                $user = "";
                $email = "";
                $_POST['password'] = "";
                $_POST['cpassword'] = "";
            } else {
                echo "<script>alert('Woops! Terjadi kesalahan.')</script>";
            }
        } else {
            echo "<script>alert('Woops! NIM anda Sudah Terdaftar.')</script>";
        }
    } else {
        echo "<script>alert('Password Tidak Sesuai')</script>";
    }
} else {
    $nim = '';
    $nama_mhs = '';
    $prodi = '';
    $email = '';

    // login user
    // $user = '';
    $password = '';
    $cpassword = '';
}

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="style.css">

    <title>Daftar</title>
</head>

<body>
    <div class="container">
        <form
            action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
            method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Form Pendaftaran</p>
            <div class="input-group">
                <input type="text" placeholder="NIM (Nomor Induk Mahasiswa)" name="nim"
                    value="<?php echo$nim ?>" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="Nama Lengkap" name="nama"
                    value="<?php echo $nama_mhs ?>" required>
            </div>
            <div class="input-group">
                <select name="prodi" id="">
                    <option value="" style="color:#111;">Pilih Prodi</option>
                    <option value="1" style="color:#111;">Teknik Informatika</option>
                    <option value="2" style="color:#111;">Illmu Pemerintahan</option>
                    <option value="3" style="color:#111;">PGSD</option>
                    <option value="4" style="color:#111;">Manajemen</option>
                    <option value="5" style="color:#111;">Ekonomi Pembangunan</option>
                </select>
            </div>
            <div class="input-group">
                <input type="email" placeholder="Email" name="email"
                    value="<?php echo$email ?>" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password"
                    value="<?php echo$nim ?>" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Confirm Password" name="cpassword" required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Register</button>
            </div>
            <p class="login-register-text">Anda sudah punya akun? <a href="index.php">Login </a></p>
        </form>
    </div>
</body>

</html>
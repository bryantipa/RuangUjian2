<?php 
 
include 'config.php';
 
error_reporting(0);

session_start();
//  // jika anda sudah melakukan login sebelumnya, maka anda akan dialihkan ke bagian ujian
// if (isset($_SESSION['nim']) || isset($_SESSION['nama'])) {
//     header("Location:ujian/");
// }else{
//     // header("location:index.php");
// }
 
if (isset($_POST['submit'])) {
    $nim = $_POST['nim'];
    $password = md5($_POST['pass']);
 
    $sql = "SELECT * FROM tb_mhs WHERE nim='$nim' AND login_pass='$password'";
    $result = mysqli_query($conn, $sql);
    if ($result->num_rows > 0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['nim'] = $row['nim'];
		$_SESSION['nama'] = $row['nama_mhs'];
		$_SESSION['prodi'] = $row['kode_prodi'];
        header("Location:../ujian/index.php");
    } else {
        echo "<script>alert('NIM atau password Anda salah. Silahkan coba lagi!')</script>";
    }
}
 
?>
 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" /> 
    <title>Masuk</title>
</head>
<body>
    <div class="alert alert-warning" role="alert">
        <?php echo $_SESSION['error']?>
    </div>
 
    <div class="container" data-aos="fade-up"
     data-aos-duration="3000">
        <form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Login</p>
            <div class="input-group">
                <input type="text" placeholder="NIM" name="nim" value="<?php echo $nim; ?>" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="pass" value="<?php echo $_POST['login_pass']; ?>" required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Login</button>
            </div>
            <div class="input-group">
                <a href="../" class="btn btn-warning" style="background:red;text-decoration:none;">Keluar</a>
            </div>
            <p class="login-register-text">Anda belum punya akun? <a href="register.php">Register</a></p>
        </form>
    </div>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>
</body>
</html>